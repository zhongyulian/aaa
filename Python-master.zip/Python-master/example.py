x = 12
y = 13

print 'x =', x, id(x)
print  'y=', y, id(y)
